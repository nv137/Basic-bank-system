# Radianitebank
Basic banking system using html ,css,php and  mysql.
